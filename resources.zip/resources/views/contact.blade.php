<x-app-layout title="{{ app()->getLocale()=='en' ? 'Contact Us | Sema Al-Khalij' : 'تواصل معنا | سيما الخليج للخدمات الطبية' }}">

    {{-- =================== HERO BANNER =================== --}}
    <section class="relative py-16 sm:py-20 bg-gradient-to-br from-[#071f18] via-primary to-[#0a3428] text-white overflow-hidden">
        <div class="absolute inset-0 pointer-events-none">
            <div class="absolute top-1/2 left-1/3 -translate-y-1/2 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
            <div class="absolute inset-0 opacity-[0.03]" style="background-image: radial-gradient(circle, #fff 1px, transparent 1px); background-size: 32px 32px;"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
            <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-bold text-medical-100">
                <svg class="w-4 h-4 text-accent" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <span>{{ __('contact.badge') }}</span>
            </div>

            <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
                {{ __('contact.heading') }}
            </h1>

            <p class="text-medical-200 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
                {{ __('contact.text') }}
            </p>
        </div>
    </section>

    {{-- =================== QUICK CONTACT CARDS =================== --}}
    <section class="py-10 bg-white border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {{-- Card 1: Phone --}}
                <a href="tel:+966545880082" class="p-6 rounded-2xl bg-surface border border-gray-100 shadow-soft hover:shadow-card hover:border-accent/30 transition-all duration-300 flex items-center gap-4 group">
                    <div class="w-12 h-12 rounded-xl bg-accent/10 text-accent flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:text-white transition-all duration-300">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    </div>
                    <div>
                        <span class="block text-xs font-bold text-gray-400">{{ __('contact.phone_label') }}</span>
                        <span dir="ltr" class="inline-block text-base font-black text-primary group-hover:text-accent transition-colors">+966 54 588 0082</span>
                        <span class="block text-[11px] text-accent font-bold">{{ __('contact.phone_avail') }}</span>
                    </div>
                </a>

                {{-- Card 2: Email --}}
                <a href="mailto:c.care@s-sema.com" class="p-6 rounded-2xl bg-surface border border-gray-100 shadow-soft hover:shadow-card hover:border-accent/30 transition-all duration-300 flex items-center gap-4 group">
                    <div class="w-12 h-12 rounded-xl bg-accent/10 text-accent flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:text-white transition-all duration-300">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    </div>
                    <div>
                        <span class="block text-xs font-bold text-gray-400">{{ __('contact.email_label') }}</span>
                        <span class="block text-base font-black text-primary group-hover:text-accent transition-colors">c.care@s-sema.com</span>
                        <span class="text-[11px] text-gray-500">{{ __('contact.email_avail') }}</span>
                    </div>
                </a>

                {{-- Card 3: Address --}}
                <div class="p-6 rounded-2xl bg-surface border border-gray-100 shadow-soft flex items-center gap-4">
                    <div class="w-12 h-12 rounded-xl bg-accent/10 text-accent flex items-center justify-center shrink-0">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
                    </div>
                    <div>
                        <span class="block text-xs font-bold text-gray-400">{{ __('contact.location_label') }}</span>
                        <span class="block text-base font-black text-primary">{{ __('contact.location_avail') }}</span>
                        <span class="text-[11px] text-gray-500">{{ __('contact.location_sub') }}</span>
                    </div>
                </div>

            </div>
        </div>
    </section>

    {{-- =================== CONTACT FORM & MAP SECTION =================== --}}
    <section class="py-12 lg:py-16 bg-surface">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-10">
                
                {{-- Contact Form (7 cols) --}}
                <div class="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl shadow-soft border border-gray-100 space-y-6">
                    <div class="space-y-2">
                        <div class="section-badge">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                            <span>{{ __('contact.form_badge') }}</span>
                        </div>
                        <h2 class="text-2xl font-black text-primary">{{ __('contact.form_heading') }}</h2>
                        <p class="text-xs text-gray-500">{!! app()->getLocale()=='en' ? 'Fill in the form below and our representative will contact you right away.' : 'قم بتعبئة النموذج أدناه وسيقوم ممثل خدمة العملاء بالتواصل معك فوراً.' !!}</p>
                    </div>

                    <form @submit.prevent="alert('{{ app()->getLocale()=='en' ? 'Your message was received successfully! Our team will contact you shortly.' : 'تم استلام رسالتك بنجاح! سيتواصل معك الفريق الطبي فوراً.' }}');" class="space-y-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-gray-700 mb-1.5">{{ __('contact.name_label') }} <span class="text-red-500">*</span></label>
                                <input type="text" required placeholder="{{ __('contact.name_placeholder') }}" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-primary focus:bg-white transition-all">
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-700 mb-1.5">{{ __('contact.phone_field_label') }} <span class="text-red-500">*</span></label>
                                <input type="tel" required placeholder="{{ __('contact.phone_field_placeholder') }}" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-primary focus:bg-white transition-all {{ app()->getLocale()=='en' ? 'text-left' : 'dir-ltr text-right' }}">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-gray-700 mb-1.5">{{ __('contact.email_field_label') }} <span class="text-red-500">*</span></label>
                                <input type="email" required placeholder="{{ __('contact.email_field_placeholder') }}" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-primary focus:bg-white transition-all">
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-700 mb-1.5">{{ __('contact.service_field_label') }}</label>
                                <select class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-primary focus:bg-white transition-all cursor-pointer">
                                    <option value="">{{ __('contact.service_placeholder') }}</option>
                                    <option value="nursing">{{ __('contact.service_nursing') }}</option>
                                    <option value="doctor">{{ __('contact.service_doctor') }}</option>
                                    <option value="physio">{{ __('contact.service_physio') }}</option>
                                    <option value="labs">{{ __('contact.service_labs') }}</option>
                                    <option value="genetics">{{ __('contact.service_genetics') }}</option>
                                    <option value="corporate">{{ __('contact.service_corporate') }}</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-gray-700 mb-1.5">{{ __('contact.message_label') }} <span class="text-red-500">*</span></label>
                            <textarea rows="4" required placeholder="{{ __('contact.message_placeholder') }}" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-primary focus:bg-white transition-all resize-none"></textarea>
                        </div>

                        <div class="pt-2">
                            <button type="submit" class="w-full btn-accent py-3.5 rounded-xl font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2">
                                <span>{{ __('contact.send_btn') }}</span>
                                <svg class="w-4 h-4 {{ app()->getLocale()=='en' ? 'rotate-180' : '' }}" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                            </button>
                        </div>

                        <p class="text-[11px] text-gray-400 text-center">
                            {{ __('contact.pdpl_note') }}
                        </p>
                    </form>
                </div>

                {{-- Right Info & Map (5 cols) --}}
                <div class="lg:col-span-5 space-y-6">
                    
                    {{-- Direct WhatsApp CTA Card --}}
                    <div class="bg-gradient-to-br from-primary to-[#0c4031] text-white p-6 rounded-3xl shadow-soft space-y-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-[#25D366] text-white flex items-center justify-center shrink-0 shadow-md">
                                <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-1.157 4.228 4.305-1.129z"/></svg>
                            </div>
                            <div>
                                <h3 class="font-bold text-base">{{ __('contact.wa_card_title') }}</h3>
                                <p class="text-[11px] text-medical-200">{{ __('contact.wa_card_sub') }}</p>
                            </div>
                        </div>
                        <a href="https://wa.me/966545880082?text={{ urlencode(app()->getLocale()=='en' ? 'Hello, I would like to inquire about Sema Al-Khalij home medical services.' : 'السلام عليكم، أود الاستفسار عن خدمات سيما الخليج الطبية المنزلية') }}" target="_blank" class="w-full inline-flex items-center justify-center gap-2 py-3 bg-[#25D366] text-white font-bold rounded-xl text-xs hover:opacity-90 transition-all shadow-md">
                            <span>{{ __('contact.wa_card_btn') }}</span>
                            <svg class="w-4 h-4 {{ app()->getLocale()=='en' ? 'rotate-180' : '' }}" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                        </a>
                    </div>

                    {{-- Google Maps Embed --}}
                    <div class="bg-white rounded-3xl shadow-soft border border-gray-100 overflow-hidden h-72 relative">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3711.2!2d39.18!3d21.53!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDMxJzQ4LjAiTiAzOcKwMTAnNDguMCJF!5e0!3m2!1sar!2ssa!4v1" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="w-full h-full"></iframe>
                    </div>

                </div>

            </div>
        </div>
    </section>

</x-app-layout>
